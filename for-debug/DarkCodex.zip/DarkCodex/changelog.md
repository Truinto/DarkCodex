# Changelog

## [1.0.4]

## [1.0.3]
- added bleeding attack
- added flensing strike
- added missing gui elements
- added mythic limitless smite
- added mythic kinetic mastery
- fixed wall infusion
- bugfixes

## [1.0.2]

### Added
- fix hexcrafter lv3 hex arcana selection; lv11 spell recall
- cold iron arrows refresh after combat
- a kineticist background
- kinetic blasts apply gather power, even if a weaker mode is picked
- mobile gathering
- made gather power ability visible
- extra wild talent
- option to allow achievements; this also clears the corresponding flag from future save files (otherwise uninstalling all mods would prevent achievements again)
- impale infusion
- ice tomb
- extra rogue talent
- buffed angel's light
- cackle/shant passive activatable
- ability focus

## [1.0.1]

### Added

- first release